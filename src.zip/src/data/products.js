import product1 from "../Assets/LetsShop_Images/images/product-01.jpg";
import product2 from "../Assets/LetsShop_Images/images/product-02.jpg";
import product3 from "../Assets/LetsShop_Images/images/product-03.jpg";
import product4 from "../Assets/LetsShop_Images/images/product-04.jpg";
import product5 from "../Assets/LetsShop_Images/images/product-05.jpg";
import product6 from "../Assets/LetsShop_Images/images/product-06.jpg";
import product7 from "../Assets/LetsShop_Images/images/product-07.jpg";
import product8 from "../Assets/LetsShop_Images/images/product-08.jpg";
import product9 from "../Assets/LetsShop_Images/images/product-09.jpg";
import product10 from "../Assets/LetsShop_Images/images/product-10.jpg";
import product11 from "../Assets/LetsShop_Images/images/product-11.jpg";
import product12 from "../Assets/LetsShop_Images/images/product-12.jpg";
import product13 from "../Assets/LetsShop_Images/images/product-13.jpg";
import product14 from "../Assets/LetsShop_Images/images/product-14.jpg";
import product15 from "../Assets/LetsShop_Images/images/product-15.jpg";
import product16 from "../Assets/LetsShop_Images/images/product-16.jpg";

export const products = [
  {
    id: 1,
    title: "White T-Shirt",
    price: "549/-",
    image: product1,
  },
  {
    id: 2,
    title: "White Shirt",
    price: "799/-",
    image: product2,
  },
  {
    id: 3,
    title: "Raymond Shirt",
    price: "999/-",
    image: product3,
  },
  {
    id: 4,
    title: "Winter Jacket",
    price: "2999/-",
    image: product4,
  },
  {
    id: 5,
    title: "Premium Combo",
    price: "999/-",
    image: product5,
  },
  {
    id: 6,
    title: "SONATA",
    price: "4999/-",
    image: product6,
  },
  {
    id: 7,
    title: "Suit",
    price: "1199/-",
    image: product7,
  },
  {
    id: 8,
    title: "T-Shirt",
    price: "499/-",
    image: product8,
  },
  {
    id: 9,
    title: "Sneker's",
    price: "2099/-",
    image: product9,
  },
  {
    id: 10,
    title: "Black Top",
    price: "699/-",
    image: product10,
  },
  {
    id: 11,
    title: "Blue primium Shirt",
    price: "2000/-",
    image: product11,
  },
  {
    id: 12,
    title: "Pure Lathner Belt",
    price: "399/-",
    image: product12,
  },
  {
    id: 13,
    title: "Combo",
    price: "1299/-",
    image: product13,
  },
  {
    id: 14,
    title: "Black Top",
    price: "949/-",
    image: product14,
  },
  {
    id: 15,
    title: "TITAN",
    price: "7999/-",
    image: product15,
  },
  {
    id: 16,
    title: "Sleep Wear Combo",
    price: "2099/-",
    image: product16,
  },
];
